"""Point-cloud corridor detection and a deterministic stopping-distance rule."""

from dataclasses import dataclass

import torch


@dataclass(frozen=True)
class BrakeConfig:
    lookahead_m: float = 16.0
    path_segments: int = 16
    corridor_radius_m: float = 0.72
    stand_off_m: float = 0.85
    deceleration_mps2: float = 2.5
    reaction_s: float = 0.25
    release_samples: int = 2


def first_return_distance(points, valid, path, stations, radius_m):
    """Return the earliest observed obstacle along a swept path, or infinity.

    Points and path vertices share a local metric frame. Stations are distances
    along the reference route from the current progress estimate.
    """
    start = path[:, :-1]
    segment = path[:, 1:] - start
    length_sq = segment.square().sum(-1)[:, None, :]
    projected = points @ segment.transpose(-1, -2) - (start * segment).sum(-1)[:, None, :]
    fraction = (projected / length_sq.clamp_min(1e-8)).clamp(0, 1)
    start_dist_sq = (points.square().sum(-1, keepdim=True) + start.square().sum(-1)[:, None, :]
                     - 2 * (points @ start.transpose(-1, -2)))
    dist_sq = start_dist_sq - 2 * fraction * projected + fraction.square() * length_sq
    distance = stations[:-1] + fraction * stations.diff()
    inside = valid[:, :, None] & (dist_sq <= radius_m**2)
    return torch.where(inside, distance, torch.inf).amin(dim=(1, 2))


def stopping_speed(distance_m, deceleration_mps2, reaction_s):
    """Solve speed * reaction + speed² / (2 * deceleration) <= distance."""
    reaction_speed = deceleration_mps2 * reaction_s
    return (reaction_speed**2 + 2 * deceleration_mps2 * distance_m.clamp_min(0)).sqrt() - reaction_speed
